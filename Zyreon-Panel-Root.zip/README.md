# Zyreon Panel

Zyreon Panel is a customized/rebranded distribution based on the open-source Pterodactyl Panel project.

> **Attribution:** Zyreon Panel is not an official Pterodactyl release. The original Pterodactyl copyright notices and MIT license are retained in `LICENSE.md`.

## Features

Pterodactyl provides a web-based game server management panel built with PHP, React, and Go, with server isolation through Docker. Zyreon Panel keeps that core architecture while applying Zyreon branding.

## Documentation

For upstream documentation and installation guidance:
- https://pterodactyl.io/panel/1.0/getting_started.html
- https://pterodactyl.io/wings/1.0/installing.html
- https://pterodactyl.io/community/about.html

## Supported games

The upstream panel supports many game servers through Docker-based containers, including Minecraft, Rust, Terraria, TeamSpeak, Mumble, Team Fortress 2, Counter-Strike, Garry's Mod, and ARK: Survival Evolved, with additional community eggs available.

## Credits

- Original project: Pterodactyl Panel — https://pterodactyl.io/
- Original source: https://github.com/pterodactyl/panel
- Original authors/contributors: see `LICENSE.md` and `composer.json`
- Full rebrand/attribution notes: `ZYREON_CREDITS.md`

## License

The original Pterodactyl MIT license is included in `LICENSE.md` and must remain with redistributed copies.


## Zyreon Panel Promotion

**Powered by Zyreon Panel**

- Website: https://zyreonpanel.bond/
- Discord: https://dsc.gg/zyreon/
- Owner: Arrow
- Developer: Arrow
- Support: aaravdulal0@gmail.com
- X: Soon
- YouTube: @arrowsarkar
- Discord: @arrowsarkar
- Instagram: @arrowsarkar_

Zyreon Panel is a customized and rebranded distribution based on the Pterodactyl Panel open-source project.
