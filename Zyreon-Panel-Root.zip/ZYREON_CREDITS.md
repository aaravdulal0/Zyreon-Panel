# Zyreon Panel — Credits, Attribution & Promotion

**Powered by Zyreon Panel**

## Zyreon
- Website: https://zyreonpanel.bond/
- Discord: https://dsc.gg/zyreon/
- Owner: Arrow
- Developer: Arrow
- Support: aaravdulal0@gmail.com
- X: Soon
- YouTube: @arrowsarkar
- Discord: @arrowsarkar
- Instagram: @arrowsarkar_

## Upstream attribution
Zyreon Panel is a customized and rebranded distribution based on the Pterodactyl Panel open-source project. The original Pterodactyl copyright notices and MIT license are retained in `LICENSE.md`. This project is not an official Pterodactyl release.
