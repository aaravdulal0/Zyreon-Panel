<?php

namespace Pterodactyl\Tests\Integration\Api\Client\Server\ScheduleTask;

use Pterodactyl\Models\Task;
use Illuminate\Http\Response;
use Pterodactyl\Models\Schedule;
use Pterodactyl\Models\Permission;
use Pterodactyl\Tests\Integration\Api\Client\ClientApiIntegrationTestCase;

class CreateServerScheduleTaskTest extends ClientApiIntegrationTestCase
{
    /**
     * Test that a task can be created.
     */
    #[\PHPUnit\Framework\Attributes\DataProvider('permissionsDataProvider')]
    public function testTaskCanBeCreated(array $permissions)
    {
        [$user, $server] = $this->generateTestAccount($permissions);

        /** @var Schedule $schedule */
        $schedule = Schedule::factory()->create(['server_id' => $server->id]);
        $this->assertEmpty($schedule->tasks);

        $response = $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => 'command',
            'payload' => 'say Test',
            'time_offset' => 10,
            'sequence_id' => 1,
        ]);

        $response->assertOk();
        /** @var Task $task */
        $task = Task::query()->findOrFail($response->json('attributes.id'));

        $this->assertSame($schedule->id, $task->schedule_id);
        $this->assertSame(1, $task->sequence_id);
        $this->assertSame('command', $task->action);
        $this->assertSame('say Test', $task->payload);
        $this->assertSame(10, $task->time_offset);
        $this->assertJsonTransformedWith($response->json('attributes'), $task);
    }

    /**
     * Test that validation errors are returned correctly if bad data is passed into the API.
     */
    public function testValidationErrorsAreReturned()
    {
        [$user, $server] = $this->generateTestAccount();

        /** @var Schedule $schedule */
        $schedule = Schedule::factory()->create(['server_id' => $server->id]);

        $response = $this->actingAs($user)->postJson($this->link($schedule, '/tasks'))->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY);

        foreach (['action', 'payload', 'time_offset'] as $i => $field) {
            $response->assertJsonPath("errors.$i.meta.rule", $field === 'payload' ? 'required_unless' : 'required');
            $response->assertJsonPath("errors.$i.meta.source_field", $field);
        }

        $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => 'hodor',
            'payload' => 'say Test',
            'time_offset' => 0,
        ])
            ->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY)
            ->assertJsonPath('errors.0.meta.rule', 'in')
            ->assertJsonPath('errors.0.meta.source_field', 'action');

        $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => 'command',
            'time_offset' => 0,
        ])
            ->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY)
            ->assertJsonPath('errors.0.meta.rule', 'required_unless')
            ->assertJsonPath('errors.0.meta.source_field', 'payload');

        $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => 'command',
            'payload' => 'say Test',
            'time_offset' => 0,
            'sequence_id' => 'hodor',
        ])
            ->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY)
            ->assertJsonPath('errors.0.meta.rule', 'numeric')
            ->assertJsonPath('errors.0.meta.source_field', 'sequence_id');
    }

    /**
     * Test that backups can not be tasked when the backup limit is 0.
     */
    public function testBackupsCanNotBeTaskedIfLimit0()
    {
        [$user, $server] = $this->generateTestAccount();

        /** @var Schedule $schedule */
        $schedule = Schedule::factory()->create(['server_id' => $server->id]);

        $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => 'backup',
            'time_offset' => 0,
        ])
            ->assertStatus(Response::HTTP_FORBIDDEN)
            ->assertJsonPath('errors.0.detail', 'A backup task cannot be created when the server\'s backup limit is set to 0.');

        $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => 'backup',
            'payload' => "file.txt\nfile2.log",
            'time_offset' => 0,
        ])
            ->assertStatus(Response::HTTP_FORBIDDEN)
            ->assertJsonPath('errors.0.detail', 'A backup task cannot be created when the server\'s backup limit is set to 0.');
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('missingActionPermissionDataProvider')]
    public function testTaskCannotBeCreatedWithoutActionPermission(string $action, ?string $payload)
    {
        [$user, $server] = $this->generateTestAccount([Permission::ACTION_SCHEDULE_UPDATE]);
        $server->forceFill(['backup_limit' => 1])->save();

        /** @var Schedule $schedule */
        $schedule = Schedule::factory()->create(['server_id' => $server->id]);

        $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => $action,
            'payload' => $payload,
            'time_offset' => 0,
        ])->assertForbidden();
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('actionPermissionDataProvider')]
    public function testTaskCanBeCreatedWithActionPermission(string $action, ?string $payload, string $permission)
    {
        [$user, $server] = $this->generateTestAccount([Permission::ACTION_SCHEDULE_UPDATE, $permission]);
        $server->forceFill(['backup_limit' => 1])->save();

        /** @var Schedule $schedule */
        $schedule = Schedule::factory()->create(['server_id' => $server->id]);

        $response = $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => $action,
            'payload' => $payload,
            'time_offset' => 0,
        ]);

        $response->assertOk();
        $this->assertDatabaseHas('tasks', [
            'schedule_id' => $schedule->id,
            'action' => $action,
            'payload' => $payload ?? '',
        ]);
    }

    public function testPowerTaskRequiresValidPayload()
    {
        [$user, $server] = $this->generateTestAccount([
            Permission::ACTION_SCHEDULE_UPDATE,
            Permission::ACTION_CONTROL_START,
        ]);

        /** @var Schedule $schedule */
        $schedule = Schedule::factory()->create(['server_id' => $server->id]);

        $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => 'power',
            'payload' => 'invalid',
            'time_offset' => 0,
        ])
            ->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY)
            ->assertJsonPath('errors.0.meta.rule', 'in')
            ->assertJsonPath('errors.0.meta.source_field', 'payload');
    }

    /**
     * Test that an error is returned if the user attempts to create an additional task that
     * would put the schedule over the task limit.
     */
    public function testErrorIsReturnedIfTooManyTasksExistForSchedule()
    {
        config()->set('pterodactyl.client_features.schedules.per_schedule_task_limit', 2);

        [$user, $server] = $this->generateTestAccount();

        /** @var Schedule $schedule */
        $schedule = Schedule::factory()->create(['server_id' => $server->id]);
        Task::factory()->times(2)->create(['schedule_id' => $schedule->id]);

        $this->actingAs($user)->postJson($this->link($schedule, '/tasks'), [
            'action' => 'command',
            'payload' => 'say test',
            'time_offset' => 0,
        ])
            ->assertStatus(Response::HTTP_BAD_REQUEST)
            ->assertJsonPath('errors.0.code', 'ServiceLimitExceededException')
            ->assertJsonPath('errors.0.detail', 'Schedules may not have more than 2 tasks associated with them. Creating this task would put this schedule over the limit.');
    }

    /**
     * Test that an error is returned if the targeted schedule does not belong to the server
     * in the request.
     */
    public function testErrorIsReturnedIfScheduleDoesNotBelongToServer()
    {
        [$user, $server] = $this->generateTestAccount();
        $server2 = $this->createServerModel(['owner_id' => $user->id]);

        /** @var Schedule $schedule */
        $schedule = Schedule::factory()->create(['server_id' => $server2->id]);

        $this->actingAs($user)
            ->postJson("/api/client/servers/$server->uuid/schedules/$schedule->id/tasks")
            ->assertNotFound();
    }

    /**
     * Test that an error is returned if the subuser making the request does not have permission
     * to update a schedule.
     */
    public function testErrorIsReturnedIfSubuserDoesNotHaveScheduleUpdatePermissions()
    {
        [$user, $server] = $this->generateTestAccount([Permission::ACTION_SCHEDULE_CREATE]);

        /** @var Schedule $schedule */
        $schedule = Schedule::factory()->create(['server_id' => $server->id]);

        $this->actingAs($user)
            ->postJson($this->link($schedule, '/tasks'))
            ->assertForbidden();
    }

    public static function permissionsDataProvider(): array
    {
        return [[[]], [[Permission::ACTION_SCHEDULE_UPDATE, Permission::ACTION_CONTROL_CONSOLE]]];
    }

    public static function missingActionPermissionDataProvider(): array
    {
        return [
            ['command', 'say Test'],
            ['power', 'start'],
            ['power', 'stop'],
            ['power', 'restart'],
            ['power', 'kill'],
            ['backup', null],
        ];
    }

    public static function actionPermissionDataProvider(): array
    {
        return [
            ['command', 'say Test', Permission::ACTION_CONTROL_CONSOLE],
            ['power', 'start', Permission::ACTION_CONTROL_START],
            ['power', 'stop', Permission::ACTION_CONTROL_STOP],
            ['power', 'restart', Permission::ACTION_CONTROL_RESTART],
            ['power', 'kill', Permission::ACTION_CONTROL_STOP],
            ['backup', null, Permission::ACTION_BACKUP_CREATE],
        ];
    }
}
